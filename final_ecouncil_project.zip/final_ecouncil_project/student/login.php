
<?php
include "db.php";  
session_start();
$msg='';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $pass = $_POST['password'];
    $res = $conn->query("SELECT * FROM students WHERE email='$email'");
    if ($res && $res->num_rows===1) {
        $row = $res->fetch_assoc();
        if (password_verify($pass, $row['password'])) {
            $_SESSION['student_id'] = (int)$row['id'];
            header('Location: dashboard.php');
            exit;
        } else $msg='Invalid credentials';
    } else $msg='No user found';
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>login - Study@VC</title>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-8 bg-white p-4 rounded shadow">
        <h3 class="text-center mb-4">LOGIN PAGE</h3>
		<?php if($msg) echo '<p style="color:red;">'.htmlspecialchars($msg).'</p>'; ?>
<form method="post">
          <div class="mb-3">
            <label>USER NAME</label>
			
            <input type="text" name="email" class="form-control" required>
          </div>
          
          <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <div class="d-grid">
            <button type="submit" class="btn btn-success">LOGIN</button>
          </div>
        </form>
        <hr>
        <p class="text-center mt-3">NEW USER?<a href="register.php">Register</a></p>
        </p>
      </div>
    </div>
  </div>
</body>
</html>
