<?php
session_start();
include 'db.php';
if(!isset($_SESSION['student_id'])){ header('Location:index.php'); exit; }
$res = $conn->query('SELECT * FROM messages ORDER BY created_at DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Messages</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="container mt-4">
<h3>Messages</h3>
<?php while($m=$res->fetch_assoc()){ ?>
  <div class="card mb-2"><div class="card-body">
    <strong><?=htmlspecialchars($m['sender'])?></strong> <small class="text-muted"><?=htmlspecialchars($m['created_at'])?></small>
    <p><?=nl2br(htmlspecialchars($m['message']))?></p>
  </div></div>
<?php } ?>
<a href="dashboard.php" class="btn btn-link">Back</a>
</body></html>