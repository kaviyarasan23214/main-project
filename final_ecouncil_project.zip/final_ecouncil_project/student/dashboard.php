<?php
session_start();
include 'db.php';
if(!isset($_SESSION['student_id'])){ header('Location:index.php'); exit; }
$stu = $conn->query('SELECT * FROM students WHERE id='.(int)$_SESSION['student_id'])->fetch_assoc();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
<div class="container mt-4">
  <div class="card p-3 shadow">
    <div class="d-flex justify-content-between">
      <h4>Welcome, <?=htmlspecialchars($stu['name'])?></h4>
      <a href="logout.php" class="btn btn-sm btn-outline-secondary">Logout</a>
    </div>
    <hr>
    <a href="eligibility.php" class="btn btn-primary">Eligibility Status</a>
    <a href="application.php" class="btn btn-success">Application Form</a>
    <a href="messages.php" class="btn btn-info">Messages</a>
  </div>
</div>
</body>
</html>