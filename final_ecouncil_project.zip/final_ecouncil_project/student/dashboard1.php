
<?php
include "db.php";
session_start();
if (!isset($_SESSION['student_id'])) { header('Location: login.php'); exit; }
$student_id = (int)$_SESSION['student_id'];

$res = $conn->query("SELECT s.*, c.course_name FROM selections s JOIN courses c ON c.id=s.course_id WHERE s.student_id=$student_id AND s.selected=1");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Dashboard</title></head><body>
<h2>Student Dashboard</h2>
<?php
if ($res && $res->num_rows>0) {
    echo '<h3>You are selected for:</h3><ul>';
    while($r=$res->fetch_assoc()){
        echo '<li>'.htmlspecialchars($r['course_name']).' - <a href="application_form.php?course_id='.(int)$r['course_id'].'">Fill Application</a></li>';
    }
    echo '</ul>';
} else {
    echo '<p>You are not selected or selection not yet run. Contact admin.</p>';
}
?>
<p><a href="logout.php">Logout</a></p>
</body></html>
