<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}

$name          = $_POST['name'];
$email         = $_POST['email'];
$student_group = $_POST['student_group'];
$marks         = (int) $_POST['marks'];
$community     = $_POST['community'];
$username      = $_POST['username'];
$password      = password_hash($_POST['password'], PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO students (name, email, student_group, marks, community, username, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("sssisss", $name, $email, $student_group, $marks, $community, $username, $password);

if ($stmt->execute()) {
    echo "<script>alert('Registered successfully');window.location='index.php';</script>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>