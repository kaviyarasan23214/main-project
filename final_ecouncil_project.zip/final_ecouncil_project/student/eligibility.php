<?php
session_start();
include 'db.php';
if(!isset($_SESSION['student_id'])){ header('Location:index.php'); exit; }
$stu = $conn->query('SELECT * FROM students WHERE id='.(int)$_SESSION['student_id'])->fetch_assoc();
$now = date('Y-m-d H:i:s');
$ctrl = $conn->query('SELECT * FROM admission_dates ORDER BY id DESC LIMIT 1')->fetch_assoc();
if(!$ctrl || $now < $ctrl['open_date'] || $now > $ctrl['close_date']){
    echo "<div class='container mt-4'><div class='alert alert-warning'>Admission closed. Contact admin.</div></div>"; exit;
}
$courses = $conn->query("SELECT * FROM courses WHERE eligible_group='".$conn->real_escape_string($stu['group_name'])."'") or die($conn->error);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Eligibility</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class='container mt-4'>
  <h3>Eligible Courses for <?=htmlspecialchars($stu['group_name'])?></h3>
  <p>Marks: <?=htmlspecialchars($stu['marks'])?></p>
  <?php if($courses->num_rows>0){ ?>
    <form method="post" action="course_select.php">
      <div class="mb-3">
        <label>Select Course</label>
        <select name="course_id" class="form-control">
          <?php while($c=$courses->fetch_assoc()){ ?>
            <option value="<?=$c['id']?>"><?=htmlspecialchars($c['course_name'])?></option>
          <?php } ?>
        </select>
      </div>
      <button class="btn btn-success">Select & Check Rank</button>
    </form>
  <?php } else { echo '<div class="alert alert-danger">No eligible courses</div>'; } ?>
</body>
</html>