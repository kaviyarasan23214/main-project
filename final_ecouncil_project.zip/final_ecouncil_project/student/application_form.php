
<?php
require_once __DIR__ . '/../includes/config.php';
session_start();
if (!isset($_SESSION['student_id'])) { header('Location: login.php'); exit; }
$student_id = (int)$_SESSION['student_id'];
$course_id = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$chk = $conn->query("SELECT * FROM selections WHERE student_id=$student_id AND course_id=$course_id AND selected=1");
if (!$chk || $chk->num_rows==0) { die('Not authorized'); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $address = $conn->real_escape_string($_POST['address']);
    $parent = $conn->real_escape_string($_POST['parent_name']);
    $contact = $conn->real_escape_string($_POST['parent_contact']);
    $stmt = $conn->prepare('INSERT INTO applications_form (student_id, course_id, address, parent_name, parent_contact) VALUES (?,?,?,?,?)');
    $stmt->bind_param('iisss',$student_id,$course_id,$address,$parent,$contact);
    if ($stmt->execute()) { header('Location: dashboard.php'); exit; } else echo 'Error: '.$stmt->error;
}
$course = $conn->query("SELECT course_name FROM courses WHERE id=$course_id")->fetch_assoc();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Application</title></head><body>
<h2>Application for <?php echo htmlspecialchars($course['course_name']); ?></h2>
<form method="post" enctype="multipart/form-data">
Address:<br><textarea name="address" required></textarea><br>
Parent name:<br><input name="parent_name" required><br>
Parent contact:<br><input name="parent_contact" required><br>
<button type="submit">Submit</button>
</form>
<p><a href="dashboard.php">Back</a></p>
</body></html>
