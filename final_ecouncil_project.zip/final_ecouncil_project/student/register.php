
<?php
include "db.php";   
$msg='';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $group = $conn->real_escape_string($_POST['group']);
    $community = $conn->real_escape_string($_POST['community']);
    $marks = (int)$_POST['marks'];

    $stmt = $conn->prepare('INSERT INTO students (name,email,password,group_name,community,marks) VALUES (?,?,?,?,?,?)');
    $stmt->bind_param('sssssi',$name,$email,$password,$group,$community,$marks);
    if ($stmt->execute()) {
        header('Location: login.php');
        exit;
    } else {
        $msg = 'Error: ' . $stmt->error;
    }
    $stmt->close();
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Register</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="col-md-8 mx-auto">
    <div class="card p-4 shadow"></head><body>
<h2>Student Register</h2>
<?php if($msg) echo '<p style="color:red;">'.htmlspecialchars($msg).'</p>'; ?>
<form method="post">
Name: <input name="name" required><br>
Email: <input name="email" type="email" required><br>
Password: <input name="password" type="password" required><br>
12th Group: <select name="group"><option>Computer Maths</option><option>Bio Maths</option></select><br>
Community: <select name="community"><option>OC</option><option>BC</option><option>MBC</option><option>SC</option><option>ST</option></select><br>
Marks: <input name="marks" type="number" required><br>
<button type="submit">Register</button>
</form>
</body></html>
