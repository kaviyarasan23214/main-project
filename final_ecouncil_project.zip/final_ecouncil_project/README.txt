
Full ECouncil project - Quick Start:

1) Copy folder 'final_ecouncil_project' to C:\xampp\htdocs\final_ecouncil_project
2) Start Apache & MySQL in XAMPP
3) Open http://localhost/phpmyadmin and import init.sql (creates 'eligibility_db' and tables)
4) Student register: /final_ecouncil_project/student/register.php
   Student login: /final_ecouncil_project/student/login.php
   Admin login: /final_ecouncil_project/admin/login.php (user: admin, pass: admin123)
5) Admin -> Manage courses, set quotas, run selection
6) Selected students can fill application form
