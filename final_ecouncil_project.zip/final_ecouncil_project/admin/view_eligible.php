
<?php
include "db.php";
session_start(); if(!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
$res = $conn->query("SELECT sel.*, s.name, s.community, s.marks, c.course_name FROM selections sel JOIN students s ON s.id=sel.student_id JOIN courses c ON c.id=sel.course_id WHERE sel.selected=1 ORDER BY c.course_name, sel.rank_in_comm");
?>
<!doctype html><html><body><h2>Eligible Students</h2>
<?php if($res && $res->num_rows){ echo '<table border=1><tr><th>Course</th><th>Rank</th><th>Name</th><th>Community</th><th>Marks</th></tr>'; while($r=$res->fetch_assoc()){ echo '<tr><td>'.htmlspecialchars($r['course_name']).'</td><td>'.(int)$r['rank_in_comm'].'</td><td>'.htmlspecialchars($r['name']).'</td><td>'.htmlspecialchars($r['community']).'</td><td>'.(int)$r['marks'].'</td></tr>'; } echo '</table>'; } else echo '<p>No eligible students yet.</p>'; ?>
<p><a href="dashboard.php">Back</a></p></body></html>
