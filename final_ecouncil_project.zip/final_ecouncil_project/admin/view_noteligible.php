
<?php
include "db.php";
session_start(); if(!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
$res = $conn->query("SELECT s.*, c.course_name FROM students s JOIN courses c ON FIND_IN_SET(s.group_name, c.eligible_groups) LEFT JOIN selections sel ON sel.student_id=s.id AND sel.course_id=c.id WHERE sel.id IS NULL ORDER BY c.course_name, s.community");
?>
<!doctype html><html><body><h2>Not Eligible Students</h2>
<?php if($res && $res->num_rows){ echo '<table border=1><tr><th>Course</th><th>Name</th><th>Community</th><th>Marks</th></tr>'; while($r=$res->fetch_assoc()){ echo '<tr><td>'.htmlspecialchars($r['course_name']).'</td><td>'.htmlspecialchars($r['name']).'</td><td>'.htmlspecialchars($r['community']).'</td><td>'.(int)$r['marks'].'</td></tr>'; } echo '</table>'; } else echo '<p>No not-eligible students.</p>'; ?>
<p><a href="dashboard.php">Back</a></p></body></html>
