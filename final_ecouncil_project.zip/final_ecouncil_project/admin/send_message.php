<?php
session_start();
include 'db.php';
if(!isset($_SESSION['admin_id'])){ header('Location: admin_login.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){
    $msg=$conn->real_escape_string($_POST['message']);
    $conn->query("INSERT INTO messages (sender,receiver,message) VALUES ('Admin','All','$msg')");
    echo "<script>alert('Message sent');window.location='admin_dashboard.php';</script>";
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Send Message</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-4">
<h3>Send Message</h3>
<form method="post"><div class="mb-3"><textarea name="messages" class="form-control" required></textarea></div><button class="btn btn-primary">Send</button></form>
<br><a href="admin_dashboard.php" class="btn btn-link">Back</a>
</body></html>