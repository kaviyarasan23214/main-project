
<?php
include "db.php";
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin</title></head><body>
<h2>Admin Dashboard</h2>
<p><a href="courses.php">Manage Courses</a> | <a href="quotas.php">Manage Quotas</a> | <a href="auto_process.php">Run Selection Now</a></p>
<p><a href="view_eligible.php">View Eligible</a> | <a href="view_noteligible.php">View Not Eligible</a></p>
<p><a href="view_eligible.php">msg</a> | <a href="send_message">msg</a></p>
<p><a href="logout.php">Logout</a></p>
</body></html>
