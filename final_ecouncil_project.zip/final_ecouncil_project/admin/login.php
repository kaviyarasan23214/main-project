
<?php
include "db.php";
session_start();
$msg='';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $conn->real_escape_string($_POST['username']);
    $pass = $_POST['password'];
    $res = $conn->query("SELECT * FROM admins WHERE username='$user'");
    if ($res && $res->num_rows==1) {
        $row = $res->fetch_assoc();
        if (password_verify($pass, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            header('Location: dashboard.php'); exit;
        } else $msg='Invalid password';
    } else $msg='Invalid username';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Login</title></head><body>
<h2>Admin Login</h2>
<?php if($msg) echo '<p style="color:red;">'.htmlspecialchars($msg).'</p>'; ?>
<form method="post">
Username: <input name="username" required><br>
Password: <input type="password" name="password" required><br>
<button type="submit">Login</button>
</form>
</body></html>
