
<?php
include "db.php"
session_start(); if(!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){ $code=$conn->real_escape_string($_POST['code']); $name=$conn->real_escape_string($_POST['name']); $groups=$conn->real_escape_string($_POST['groups']); $conn->query("INSERT INTO courses (course_code,course_name,eligible_groups) VALUES ('$code','$name','$groups') ON DUPLICATE KEY UPDATE course_name=VALUES(course_name), eligible_groups=VALUES(eligible_groups)"); }
$courses=$conn->query('SELECT * FROM courses ORDER BY course_code');
?>
<!doctype html><html><body><h2>Manage Courses</h2>
<form method="post">Code: <input name="code" required> Name: <input name="name" required> Groups CSV: <input name="groups" placeholder="Computer Maths,Bio Maths"> <button>Save</button></form>
<table border=1><tr><th>Code</th><th>Name</th><th>Groups</th></tr><?php while($c=$courses->fetch_assoc()){ echo '<tr><td>'.htmlspecialchars($c['course_code']).'</td><td>'.htmlspecialchars($c['course_name']).'</td><td>'.htmlspecialchars($c['eligible_groups']).'</td></tr>'; } ?></table>
<p><a href="dashboard.php">Back</a></p></body></html>
