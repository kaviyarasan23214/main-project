
<?php
include  "db.php";
session_start(); if(!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
$conn->query('TRUNCATE TABLE selections');
$cRes = $conn->query('SELECT * FROM courses');
while($course = $cRes->fetch_assoc()){
    $cid=(int)$course['id'];
    $groups = $conn->real_escape_string($course['eligible_groups']);
    $qRes = $conn->query('SELECT community,seats FROM course_quotas WHERE course_id='.$cid);
    while($q=$qRes->fetch_assoc()){
        $community = $conn->real_escape_string($q['community']);
        $seats = (int)$q['seats'];
        if($seats<=0) continue;
        $sql = "SELECT id,marks FROM students WHERE FIND_IN_SET(group_name, '$groups') AND community='$community' ORDER BY marks DESC, RAND()";
        $res = $conn->query($sql);
        $rank=1; $selected=0;
        while($s=$res->fetch_assoc()){
            $sid=(int)$s['id'];
            if($selected < $seats){
                $stmt = $conn->prepare('INSERT INTO selections (student_id,course_id,selected,rank_in_comm) VALUES (?,?,1,?)');
                $stmt->bind_param('iii',$sid,$cid,$rank);
                $stmt->execute(); $stmt->close();
                $selected++;
            }
            $rank++;
        }
    }
}
echo 'Selection completed. <a href="view_eligible.php">View Eligible</a>';
?>