
<?php
session_start();
include  "db.php";
if(!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){ $course_id=(int)$_POST['course_id']; $community=$conn->real_escape_string($_POST['community']); $seats=(int)$_POST['seats']; $conn->query("INSERT INTO course_quotas (course_id, community, seats) VALUES ($course_id,'$community',$seats) ON DUPLICATE KEY UPDATE seats=VALUES(seats)"); }
$courses=$conn->query('SELECT * FROM courses ORDER BY course_code'); $quotas=$conn->query('SELECT q.*, c.course_code FROM course_quotas q JOIN courses c ON c.id=q.course_id ORDER BY c.course_code,q.community');
?>
<!doctype html><html><body><h2>Manage Quotas</h2>
<form method="post">Course: <select name="course_id"><?php while($c=$courses->fetch_assoc()){ echo '<option value="'.(int)$c['id'].'">'.htmlspecialchars($c['course_code']).' - '.htmlspecialchars($c['course_name']).'</option>'; } ?></select><br>Community: <select name="community"><option>OC</option><option>BC</option><option>MBC</option><option>SC</option><option>ST</option></select><br>Seats: <input name="seats" type="number"><br><button>Save</button></form>
<h3>Existing</h3><table border=1><tr><th>Course</th><th>Community</th><th>Seats</th></tr><?php while($q=$quotas->fetch_assoc()){ echo '<tr><td>'.htmlspecialchars($q['course_code']).'</td><td>'.htmlspecialchars($q['community']).'</td><td>'.(int)$q['seats'].'</td></tr>'; } ?></table>
<p><a href="dashboard.php">Back</a></p></body></html>
