
CREATE DATABASE IF NOT EXISTS eligibility_db;
USE eligibility_db;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL
);

INSERT INTO admins (username, password)
VALUES ('admin', '$2y$10$hk7H2kvRTerx/OqGT7KuF.a1FsgZMKNiISC9U6AG1YjPy0MP4Sp9y');

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  group_name VARCHAR(50) NOT NULL,
  community VARCHAR(20) NOT NULL,
  marks INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_code VARCHAR(50) UNIQUE,
  course_name VARCHAR(150),
  eligible_groups VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS course_quotas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  community VARCHAR(20) NOT NULL,
  seats INT NOT NULL DEFAULT 0,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS selections (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  selected TINYINT(1) DEFAULT 0,
  rank_in_comm INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS applications_form (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  address TEXT,
  parent_name VARCHAR(150),
  parent_contact VARCHAR(50),
  document_path VARCHAR(255),
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- sample course
INSERT INTO courses (course_code, course_name, eligible_groups) VALUES
('CS','B.Sc Computer Science','Computer Maths'),
('MTH','B.Sc Mathematics','Computer Maths,Bio Maths');

-- sample quotas for CS
INSERT INTO course_quotas (course_id, community, seats)
SELECT id, 'BC', 18 FROM courses WHERE course_code='CS';
INSERT INTO course_quotas (course_id, community, seats)
SELECT id, 'OC', 2 FROM courses WHERE course_code='CS';
INSERT INTO course_quotas (course_id, community, seats)
SELECT id, 'MBC', 10 FROM courses WHERE course_code='CS';

-- sample quotas for MTH
INSERT INTO course_quotas (course_id, community, seats)
SELECT id, 'BC', 10 FROM courses WHERE course_code='MTH';
INSERT INTO course_quotas (course_id, community, seats)
SELECT id, 'OC', 3 FROM courses WHERE course_code='MTH';
